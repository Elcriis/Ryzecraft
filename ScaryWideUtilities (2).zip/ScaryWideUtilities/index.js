const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require("discord.js");
const fs = require("fs");
const fetch = require("node-fetch");

// Configuración y datos
const config = require("./base de datos/config.json");
let economyData = require("./base de datos/economy.json");
let warnData = require("./base de datos/warnings.json");
let banData = require("./base de datos/bans.json");
let muteData = require("./base de datos/muted.json");
let criminalRecords = require("./base de datos/criminalRecords.json"); // Added criminal records data

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildModeration,
  ],
});

// Funciones de utilidad
function saveData() {
  fs.writeFileSync("./base de datos/economy.json", JSON.stringify(economyData, null, 2));
  fs.writeFileSync("./base de datos/warnings.json", JSON.stringify(warnData, null, 2));
  fs.writeFileSync("./base de datos/bans.json", JSON.stringify(banData, null, 2));
  fs.writeFileSync("./base de datos/muted.json", JSON.stringify(muteData, null, 2));
  fs.writeFileSync("./base de datos/criminalRecords.json", JSON.stringify(criminalRecords, null, 2)); //Save criminal records
}

function getMarriages() {
  if (!fs.existsSync("./marriages.json")) {
    fs.writeFileSync("./marriages.json", JSON.stringify({ matrimonios: [] }));
  }
  const data = fs.readFileSync("./marriages.json", "utf8");
  return JSON.parse(data).matrimonios;
}

function saveMarriages(marriages) {
  fs.writeFileSync("./marriages.json", JSON.stringify({ matrimonios: marriages }, null, 2));
}

function getUserData(userId) {
  if (!economyData[userId]) {
    economyData[userId] = {
      balance: 0,
      bank: 0,
      job: null,
      lastWorked: null,
      lastRobbed: null,
    };
  }
  return economyData[userId];
}

function addCriminalRecord(userId, crime) {
  if (!criminalRecords[userId]) {
    criminalRecords[userId] = [];
  }
  criminalRecords[userId].push(crime);
}

// Event Handlers
client.on("ready", () => {
  console.log(`¡El bot está listo y funcionando!`);
  client.user.setActivity("-ayuda", { type: "PLAYING" });
});

// Message Event Handler
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const userData = getUserData(message.author.id);
  const isModerator = message.member?.roles.cache.has(config.modRoleId);

  // Comando perfil
  if (message.content.startsWith(config.prefix + "perfil")) {
    const mentionedUser = message.mentions.users.first();
    const user = mentionedUser || message.author;
    const member = message.guild.members.cache.get(user.id);

    // Calcular el estado de actividad del usuario
    const activityLevel = member.presence
      ? member.presence.activities.length > 0
        ? "Activo"
        : "Un poco más activo"
      : "Inactivo";

    // Crear el Embed con la información del perfil
    const embed = new EmbedBuilder()
      .setTitle(`👤 Perfil de ${user.username}`)
      .setThumbnail(user.avatarURL())
      .setDescription(`Aquí está el perfil de ${user.username}:`)
      .addFields(
        {
          name: "📅 **Fecha de unión al servidor:**",
          value: member.joinedAt.toDateString(),
        },
        {
          name: "📅 **Fecha de creación de cuenta:**",
          value: user.createdAt.toDateString(),
        },
        {
          name: "🎭 **Roles:**",
          value: member.roles.cache.map((role) => role.name).join(", "),
        },
        {
          name: "🏦 **Dinero en la cuenta bancaria:**",
          value: `$${userData.bank}`,
          inline: true,
        },
        {
          name: "💵 **Dinero en efectivo:**",
          value: `$${userData.balance}`,
          inline: true,
        },
        { name: "🔊 **Nivel de actividad:**", value: activityLevel },
        {
          name: "💬 **Estado en el chat:**",
          value:
            activityLevel === "Activo"
              ? "Un supremo chateando todo"
              : "Un poco más activo",
          inline: true,
        },
      )
      .setColor(0x4b0082) // Color índigo
      .setFooter({ text: "¡Gracias por usar el bot!" });

    message.channel.send({ embeds: [embed] });
  }

  // Comando trabajar
  if (message.content.startsWith(config.prefix + "trabajar")) {
    const userData = getUserData(message.author.id); // Obtiene los datos del usuario

    const now = Date.now();
    const lastWorked = userData.lastWorked;
    // Verificar si el usuario ya trabajó hoy
    if (lastWorked && now - lastWorked < 3600000) {
      // 3600000ms = 1 hora
      return message.reply(
        "¡Ya has trabajado hace menos de una hora! Espera un poco.",
      );
    }

    // Asignar trabajo y pagar
    const trabajos = ["Camarero", "Programador", "Carpintero", "Repartidor"];
    const trabajoSeleccionado =
      trabajos[Math.floor(Math.random() * trabajos.length)];
    const pago = Math.floor(Math.random() * 500) + 100; // Pago entre 100 y 500

    userData.job = trabajoSeleccionado;
    userData.balance += pago;
    userData.lastWorked = now; // Guarda la fecha de trabajo
    saveData(); // Guardar los cambios

    message.reply(
      `¡Has trabajado como ${trabajoSeleccionado} y has ganado $${pago}!`,
    );
  }

  // Comando banco
  if (message.content.startsWith(config.prefix + "banco")) {
    message.reply(`Tu saldo bancario es de $${userData.bank}`);
  }
  if (message.content.startsWith(config.prefix + "ruleta")) {
    const userData = getUserData(message.author.id); // Obtiene los datos del usuario
    const apuesta = parseInt(message.content.split(" ")[1]);

    if (isNaN(apuesta) || apuesta <= 0) {
      return message.reply(
        "Por favor, ingresa una cantidad válida para apostar.",
      );
    }

    if (apuesta > userData.balance) {
      return message.reply(
        "No tienes suficiente dinero para realizar esa apuesta.",
      );
    }
    // Generar un número aleatorio para la ruleta (1-36)
    const numeroRuleta = Math.floor(Math.random() * 37);
    const resultado =
      numeroRuleta === 0 ? "cero" : numeroRuleta % 2 === 0 ? "par" : "impar";

    // Verificar si el jugador gana
    const ganador = Math.random() < 0.5 ? "par" : "impar"; // Elección aleatoria entre par o impar
    const resultadoFinal = resultado === ganador ? "¡Ganaste!" : "Perdiste";

    if (resultadoFinal === "¡Ganaste!") {
      userData.balance += apuesta;
      message.reply(
        `La ruleta salió en el número ${numeroRuleta} (${resultado}). ${resultadoFinal} ¡Tu saldo es ahora $${userData.balance}!`,
      );
    } else {
      userData.balance -= apuesta;
      message.reply(
        `La ruleta salió en el número ${numeroRuleta} (${resultado}). ${resultadoFinal} Tu saldo es ahora $${userData.balance}.`,
      );
    }
    saveData(); // Guarda los datos después de la apuesta
  }
  if (message.content.startsWith(config.prefix + "blackjack")) {
    const userData = getUserData(message.author.id); // Obtiene los datos del usuario
    const apuesta = parseInt(message.content.split(" ")[1]);

    if (isNaN(apuesta) || apuesta <= 0) {
      return message.reply(
        "Por favor, ingresa una cantidad válida para apostar.",
      );
    }

    if (apuesta > userData.balance) {
      return message.reply(
        "No tienes suficiente dinero para realizar esa apuesta.",
      );
    }

    // Barajar cartas para el juego de blackjack
    const cartas = [
      "A",
      "2",
      "3",
      "4",
      "5",
      "6",
      "7",
      "8",
      "9",
      "10",
      "J",
      "Q",
      "K",
    ];
    const valores = {
      A: 11,
      2: 2,
      3: 3,
      4: 4,
      5: 5,
      6: 6,
      7: 7,
      8: 8,
      9: 9,
      10: 10,
      J: 10,
      Q: 10,
      K: 10,
    };

    const barajarCartas = (deck) => {
      for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]]; // Intercambiar las cartas
      }
    };

    // Función para calcular la puntuación de las cartas
    const calcularPuntaje = (mano) => {
      let puntaje = 0;
      let ases = 0;
      for (let carta of mano) {
        puntaje += valores[carta];
        if (carta === "A") ases++;
      }
      while (puntaje > 21 && ases) {
        puntaje -= 10;
        ases--;
      }
      return puntaje;
    };

    // Repartir cartas y calcular las puntuaciones
    const mazo = [...cartas, ...cartas, ...cartas, ...cartas]; // Crear un mazo
    barajarCartas(mazo);
    const manoJugador = [mazo.pop(), mazo.pop()];
    const manoBanca = [mazo.pop(), mazo.pop()];
    let puntajeJugador = calcularPuntaje(manoJugador);
    let puntajeBanca = calcularPuntaje(manoBanca);

    // Preguntar si el jugador quiere pedir más cartas
    message.reply(
      `Tu mano es: ${manoJugador.join(", ")} (${puntajeJugador})\nLa mano de la banca es: ${manoBanca[0]}, ?`,
    );

    const filtro = (response) =>
      response.author.id === message.author.id &&
      (response.content.toLowerCase() === "pedir" ||
        response.content.toLowerCase() === "plantarse");
    const collector = message.channel.createMessageCollector({
      filter: filtro,
      time: 30000, // Tiempo de espera 30 segundos
    });

    collector.on("collect", (collectedMessage) => {
      if (collectedMessage.content.toLowerCase() === "pedir") {
        manoJugador.push(mazo.pop());
        puntajeJugador = calcularPuntaje(manoJugador);
        message.reply(
          `Tu nueva mano es: ${manoJugador.join(", ")} (${puntajeJugador})`,
        );
        if (puntajeJugador > 21) {
          collector.stop("busted");
        }
      } else if (collectedMessage.content.toLowerCase() === "plantarse") {
        collector.stop("stand");
      }
    });

    collector.on("end", (collected, reason) => {
      if (reason === "busted") {
        message.reply(
          `Te pasaste con un puntaje de ${puntajeJugador}. ¡Perdiste!`,
        );
        userData.balance -= apuesta; // El jugador pierde la apuesta
      } else if (reason === "stand") {
        // La banca juega
        while (puntajeBanca < 17) {
          manoBanca.push(mazo.pop());
          puntajeBanca = calcularPuntaje(manoBanca);
        }
        message.reply(
          `La mano de la banca es: ${manoBanca.join(", ")} (${puntajeBanca})`,
        );

        if (puntajeBanca > 21 || puntajeJugador > puntajeBanca) {
          message.reply(
            `¡Ganaste! Tu puntaje: ${puntajeJugador}, Banca: ${puntajeBanca}`,
          );
          userData.balance += apuesta; // El jugador gana la apuesta
        } else if (puntajeJugador === puntajeBanca) {
          message.reply(
            `Empate. Tu puntaje: ${puntajeJugador}, Banca: ${puntajeBanca}`,
          );
        } else {
          message.reply(
            `La banca ganó. Tu puntaje: ${puntajeJugador}, Banca: ${puntajeBanca}`,
          );
          userData.balance -= apuesta; // El jugador pierde la apuesta
        }
      }

      saveData(); // Guarda los datos después del juego
    });
  }

  // Comando robarbanco
  if (message.content.startsWith(config.prefix + "robarbanco")) {
    const userData = getUserData(message.author.id);
    const now = Date.now();
    const lastRobbed = userData.lastRobbed;

    if (lastRobbed && now - lastRobbed < 3600000) {
      return message.reply("¡Ya has robado hace menos de una hora! Espera un poco.");
    }

    const probabilidad = Math.random();
    if (probabilidad < 0.6) {
      const roboExitoso = Math.floor(Math.random() * 10000) + 5000;
      userData.balance += roboExitoso;
      userData.lastRobbed = now;
      saveData();
      message.reply(`¡El robo al banco fue un éxito! Has robado $${roboExitoso}.`);
    } else {
      const multa = Math.floor(userData.balance * 0.3);
      userData.balance -= multa;
      userData.lastRobbed = now;
      addCriminalRecord(message.author.id, "Intento de robo al banco"); // Added criminal record
      saveData();
      message.reply(`¡La policía te ha pillado! Multa: $${multa}. Se ha añadido a tu expediente criminal.`);
    }
  }

  // Comando robarpersona
  if (message.content.startsWith(config.prefix + "robarpersona")) {
    const userData = getUserData(message.author.id);
    const now = Date.now();
    const lastRobbed = userData.lastRobbed;

    if (lastRobbed && now - lastRobbed < 1800000) {
      return message.reply("¡Ya has robado hace menos de 30 minutos!");
    }

    const probabilidad = Math.random();
    if (probabilidad < 0.7) {
      const roboExitoso = Math.floor(Math.random() * 1000) + 500;
      userData.balance += roboExitoso;
      userData.lastRobbed = now;
      saveData();
      message.reply(`¡Has robado $${roboExitoso} a un transeúnte!`);
    } else {
      const multa = Math.floor(userData.balance * 0.2);
      userData.balance -= multa;
      userData.lastRobbed = now;
      addCriminalRecord(message.author.id, "Intento de robo a persona"); // Added criminal record
      saveData();
      message.reply(`¡Te han pillado robando! Multa: $${multa}. Se ha añadido a tu expediente criminal.`);
    }
  }

  // Comando robarnegocio
  if (message.content.startsWith(config.prefix + "robarnegocio")) {
    const userData = getUserData(message.author.id);
    const now = Date.now();
    const lastRobbed = userData.lastRobbed;

    if (lastRobbed && now - lastRobbed < 2700000) {
      return message.reply("¡Ya has robado hace menos de 45 minutos!");
    }

    const probabilidad = Math.random();
    if (probabilidad < 0.65) {
      const roboExitoso = Math.floor(Math.random() * 3000) + 2000;
      userData.balance += roboExitoso;
      userData.lastRobbed = now;
      saveData();
      message.reply(`¡Has robado $${roboExitoso} del negocio!`);
    } else {
      const multa = Math.floor(userData.balance * 0.25);
      userData.balance -= multa;
      userData.lastRobbed = now;
      addCriminalRecord(message.author.id, "Intento de robo a negocio"); // Added criminal record
      saveData();
      message.reply(`¡La policía te ha pillado! Multa: $${multa}. Se ha añadido a tu expediente criminal.`);
    }
  }

  // Comando opositar
  if (message.content.startsWith(config.prefix + "opositar")) {
    const userData = getUserData(message.author.id);
    const args = message.content.split(" ").slice(1);
    const trabajo = args[0]?.toLowerCase();

    if (!trabajo) {
      return message.reply("Uso correcto: -opositar [juez/policia]");
    }

    if (trabajo !== "juez" && trabajo !== "policia") {
      return message.reply("Solo puedes opositar a juez o policia");
    }

    const probabilidad = Math.random();
    const costoOposicion = 5000;

    const totalMoney = userData.balance + userData.bank;
    if (totalMoney < costoOposicion) {
      return message.reply(`Necesitas $${costoOposicion} en total para pagar la oposición.`);
    }

    if (userData.balance >= costoOposicion) {
      userData.balance -= costoOposicion;
    } else {
      const fromBalance = userData.balance;
      const fromBank = costoOposicion - fromBalance;
      userData.balance = 0;
      userData.bank -= fromBank;
    }

    if (probabilidad < 0.3) {
      userData.job = trabajo.charAt(0).toUpperCase() + trabajo.slice(1);
      message.reply(`¡Felicidades! Has aprobado la oposición. Ahora eres ${userData.job}.`);
    } else {
      message.reply("Lo siento, no has aprobado la oposición. Inténtalo de nuevo.");
    }
    saveData();
  }

  // Comando dealer
  if (message.content.startsWith(config.prefix + "dealer")) {
    const userData = getUserData(message.author.id);
    const now = Date.now();
    const lastDeal = userData.lastDealt || 0;

    if (lastDeal && now - lastDeal < 1800000) {
      return message.reply("¡Espera 30 minutos entre ventas!");
    }

    const probabilidad = Math.random();
    if (probabilidad < 0.75) {
      const gramos = Math.floor(Math.random() * 5) + 1;
      const ganancia = gramos * 50;
      userData.balance += ganancia;
      userData.lastDealt = now;
      saveData();
      message.reply(`Has vendido ${gramos}G por $${ganancia}.`);
    } else {
      const multa = Math.floor(userData.balance * 0.4);
      userData.balance -= multa;
      userData.lastDealt = now;
      addCriminalRecord(message.author.id, "Tráfico de drogas"); // Added criminal record
      saveData();
      message.reply(`¡La policía te ha pillado! Multa: $${multa}. Se ha añadido a tu expediente criminal.`);
    }
  }

  // Comando warn
  if (message.content.startsWith(config.prefix + "warn")) {
    if (!message.member.roles.cache.has(config.modRoleId)) {
      return message.reply("No tienes permisos para usar este comando.");
    }
    const user = message.mentions.users.first();
    const reason = message.content.split(" ").slice(2).join(" ");
    if (!user) return message.reply("Por favor, menciona a un usuario.");
    if (!reason) return message.reply("Por favor, proporciona una razón.");

    if (!warnData[user.id]) {
      warnData[user.id] = [];
    }

    warnData[user.id].push(reason);
    saveData();

    message.channel.send(
      `⚠️ **${user.username}** ha sido advertido. Razón: ${reason}`,
    );
  }

  // Comando ban
  if (message.content.startsWith(config.prefix + "ban")) {
    if (!message.member.roles.cache.has(config.modRoleId)) {
      return message.reply("No tienes permisos para usar este comando.");
    }
    const user = message.mentions.users.first();
    const reason = message.content.split(" ").slice(2).join(" ");
    if (!user) return message.reply("Por favor, menciona a un usuario.");
    if (!reason) return message.reply("Por favor, proporciona una razón.");
    if (user.id === message.author.id) return message.reply("No puedes banearte a ti mismo.");
    if (user.id === client.user.id) return message.reply("No puedo banearme a mí mismo.");

    const member = message.guild.members.cache.get(user.id);
    if (member) {
      member
        .ban({ reason: reason })
        .then(() =>
          message.reply(
            `**${user.username}** ha sido baneado. Razón: ${reason}`,
          ),
        )
        .catch((err) => message.reply("No se pudo banear al usuario."));
    }
  }

  // Comando unban
  if (message.content.startsWith(config.prefix + "unban")) {
    const userId = message.content.split(" ")[1];
    if (!userId)
      return message.reply("Por favor, proporciona un ID de usuario.");

    message.guild.members
      .unban(userId)
      .then(() => message.reply(`**${userId}** ha sido desbaneado.`))
      .catch((err) => message.reply("No se pudo desbanear al usuario."));
  }

  // Comando clearwarn
  if (message.content.startsWith(config.prefix + "clearwarn")) {
    const user = message.mentions.users.first();
    if (!user) return message.reply("Por favor, menciona a un usuario.");

    delete warnData[user.id];
    saveData();

    message.channel.send(
      `Las advertencias de **${user.username}** han sido eliminadas.`,
    );
  }

  // Comando clear
  if (message.content.startsWith(config.prefix + "clear")) {
    const amount = parseInt(message.content.split(" ")[1]);
    if (isNaN(amount) || amount <= 0 || amount > 100) {
      return message.reply("Por favor, proporciona un número entre 1 y 100.");
    }

    message.channel.bulkDelete(amount, true).then(() => {
      message.channel.send(`Se han eliminado **${amount}** mensajes.`);
    });
  }

  // Comando tempmute
  if (message.content.startsWith(config.prefix + "tempmute")) {
    const user = message.mentions.users.first();
    const time = parseInt(message.content.split(" ")[2]);
    const reason = message.content.split(" ").slice(3).join(" ");
    if (!user) return message.reply("Por favor, menciona a un usuario.");
    if (!time) return message.reply("Por favor, proporciona un tiempo.");
    if (!reason) return message.reply("Por favor, proporciona una razón.");

    message.guild.members.cache
      .get(user.id)
      .timeout(time * 1000, reason)
      .then(() =>
        message.reply(
          `**${user.username}** ha sido silenciado por ${time} segundos. Razón: ${reason}`,
        ),
      )
      .catch((err) => message.reply("No se pudo silenciar al usuario."));
  }

  // Comando adivinanza
  if (message.content.startsWith(config.prefix + "adivinanza")) {
    const adivinanzas = [
      { pregunta: "¿Qué tiene cabeza, pero no ojos?", respuesta: "Un clavo" },
      {
        pregunta: "¿Cuántos segundos hay en un año?",
        respuesta: "12, el 2 de enero, 2 de febrero...",
      },
      {
        pregunta:
          "¿Qué es algo que cuanto más le quitas, más grande se vuelve?",
        respuesta: "Un agujero",
      },
    ];

    const adivinanza =
      adivinanzas[Math.floor(Math.random() * adivinanzas.length)];

    message.reply(`Adivinanza: ${adivinanza.pregunta}`);
    message.channel.send({
      content: "Escribe tu respuesta en los próximos 30 segundos.",
    });

    const filter = (response) => response.author.id === message.author.id;
    const collector = message.channel.createMessageCollector({
      filter,
      time: 30000,
    });

    collector.on("collect", (response) => {
      if (
        response.content.toLowerCase() === adivinanza.respuesta.toLowerCase()
      ) {
        message.reply(`¡Correcto! La respuesta era: ${adivinanza.respuesta}`);
        collector.stop();
      } else {
        message.reply(
          `Incorrecto. La respuesta correcta era: ${adivinanza.respuesta}`,
        );
        collector.stop();
      }
    });
  }
  // Comando Trivia
  if (message.content.startsWith(config.prefix + "trivia")) {
    const triviaQuestions = [
      {
        pregunta: "¿Quién pintó la Mona Lisa?",
        respuesta: "Leonardo da Vinci",
      },
      {
        pregunta: "¿Cuántos planetas hay en el sistema solar?",
        respuesta: "8",
      },
      { pregunta: "¿Qué continente es el más grande?", respuesta: "Asia" },
    ];

    const trivia =
      triviaQuestions[Math.floor(Math.random() * triviaQuestions.length)];

    message.reply(`Trivia: ${trivia.pregunta}`);
    message.channel.send("Escribe tu respuesta en los próximos 30 segundos.");

    const filter = (response) => response.author.id === message.author.id;
    const collector = message.channel.createMessageCollector({
      filter,
      time: 30000,
    });

    collector.on("collect", (response) => {
      if (response.content.toLowerCase() === trivia.respuesta.toLowerCase()) {
        message.reply(`¡Correcto! La respuesta era: ${trivia.respuesta}`);
        collector.stop();
      } else {
        message.reply(
          `Incorrecto. La respuesta correcta era: ${trivia.respuesta}`,
        );
        collector.stop();
      }
    });
  }
  // Comando Meme Generator
  if (message.content.startsWith(config.prefix + "meme")) {
    const memeTemplates = [
      { templateId: "61579", name: "Distracted Boyfriend" },
      { templateId: "87743020", name: "Mocking SpongeBob" },
    ];

    const memeTemplate =
      memeTemplates[Math.floor(Math.random() * memeTemplates.length)];

    fetch(
      `https://api.imgflip.com/caption_image?template_id=${memeTemplate.templateId}&text0=Texto1&text1=Texto2&username=${config.imgflipUsername}&password=${config.imgflipPassword}`,
    )
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          message.reply(data.data.url);
        } else {
          message.reply("Hubo un error al crear el meme.");
        }
      });
  }
  // Comando Chistes
  if (message.content.startsWith(config.prefix + "chiste")) {
    const chistes = [
      "¿Por qué los pájaros no usan Facebook? Porque ya tienen Twitter.",
      "¿Qué le dice un gusano a otro gusano? ¡Voy a dar una vuelta a la manzana!",
      "Estás tan vacío como el disco duro de mi abuela.",
    ];

    const chiste = chistes[Math.floor(Math.random() * chistes.length)];

    message.reply(chiste);
  }

  // Comando ayuda (reubicado para evitar conflicto con botones)

  if (message.content.startsWith(config.prefix + "ayuda")) {
    const ayudaButton = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("ayuda")
        .setLabel("Ayuda General")
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId("ayudaeconomia")
        .setLabel("Ayuda Economía")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("ayudamoderacion")
        .setLabel("Ayuda Moderación")
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId("ayudaentretenimiento")
        .setLabel("Ayuda Entretenimiento")
        .setStyle(ButtonStyle.Secondary),
    );

    message.reply({
      content: `**¡Hola ${message.author.username}!** Aquí tienes opciones de ayuda. Elige una:`,
      components: [ayudaButton],
    });
  }

  // Comando de matrimonio -marry
  if (message.content.startsWith("-marry") && !message.author.bot) {
    (async () => {
      try {
        const args = message.content.split(" ").slice(1);

        // Verificar si el comando tiene una mención de usuario
        if (args.length === 0) {
          return message.reply(
            "¡Debes mencionar a la persona con la que deseas casarte! Ejemplo: `-marry @usuario`",
          );
        }

        // Extraer la mención del usuario
        const userToMarry = message.mentions.users.first();

        // Verificar si el usuario existe
        if (!userToMarry) {
          return message.reply(
            "No he encontrado a ese usuario. Asegúrate de mencionar a alguien correctamente.",
          );
        }

        // Crear el mensaje de confirmación de matrimonio
        const marryEmbed = new EmbedBuilder()
          .setTitle("¿Quieres casarte?")
          .setDescription(
            `${message.author.username} quiere casarse con ${userToMarry.username}. ¿Aceptas la propuesta?`,
          )
          .setColor(0x00ff00)
          .setFooter({ text: "¡Que comience el amor!" });

        const marryButtons = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("yes")
            .setLabel("Sí, acepto")
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId("no")
            .setLabel("No, gracias")
            .setStyle(ButtonStyle.Danger),
        );

        // Enviar el mensaje de propuesta de matrimonio con botones
        const marriageMessage = await message.channel.send({
          embeds: [marryEmbed],
          components: [marryButtons],
        });

        // Manejo de interacción con los botones
        const filter = (interaction) => interaction.user.id === userToMarry.id;
        const collector = marriageMessage.createMessageComponentCollector({
          filter,
          time: 60000, // 1 minuto para responder
        });

        collector.on("collect", async (interaction) => {
          if (interaction.customId === "yes") {
            // Obtener los matrimonios actuales desde el archivo JSON
            const marriages = getMarriages();

            // Verificar si ya están casados
            const alreadyMarried = marriages.some(
              (marriage) =>
                (marriage.usuario1 === message.author.id &&
                  marriage.usuario2 === userToMarry.id) ||
                (marriage.usuario1 === userToMarry.id &&
                  marriage.usuario2 === message.author.id),
            );

            if (alreadyMarried) {
              return interaction.reply(
                `¡Ya están casados, ${message.author.username} y ${userToMarry.username}!`,
              );
            }

            // Guardar el nuevo matrimonio en el archivo JSON
            marriages.push({
              usuario1: message.author.id,
              usuario2: userToMarry.id,
            });
            saveMarriages(marriages);

            interaction.reply(
              `¡Felicidades ${message.author.username} y ${userToMarry.username}! ¡Están casados! 🎉`,
            );
          } else if (interaction.customId === "no") {
            interaction.reply(
              `${userToMarry.username} ha rechazado la propuesta. ¡Mejor suerte la próxima vez, ${message.author.username}!`,
            );
          }
        });
      } catch (error) {
        console.error("Error en el comando marry:", error);
        message.reply("Hubo un error al procesar el comando.");
      }
    })();
  }
  // Comando quitar antecedentes
  if (message.content.startsWith(config.prefix + "quitar antecedentes")) {
    if (userData.job !== "Juez") {
      return message.reply("Solo los jueces pueden quitar antecedentes penales.");
    }
    
    const user = message.mentions.users.first();
    if (!user) return message.reply("Por favor, menciona a un usuario.");
    
    if (!criminalRecords[user.id] || criminalRecords[user.id].length === 0) {
      return message.reply("Este usuario no tiene antecedentes penales.");
    }

    delete criminalRecords[user.id];
    saveData();
    message.reply(`Los antecedentes penales de ${user.username} han sido eliminados.`);
  }

  // Comando unmute
  if (message.content.startsWith(config.prefix + "unmute")) {
    const user = message.mentions.users.first();
    if (!user) return message.reply("Por favor, menciona a un usuario.");

    message.guild.members.cache
      .get(user.id)
      .timeout(null)
      .then(() => message.reply(`**${user.username}** ha sido des-silenciado.`))
      .catch((err) => message.reply("No se pudo des-silenciar al usuario."));
  }
});

// Button Interaction Handler
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isButton()) return;

  // Respuesta para el botón de ayuda general
  if (interaction.customId === "ayuda") {
    const ayudaEmbed = new EmbedBuilder()
      .setTitle("Comandos de Ayuda General")
      .setDescription(
        `
          **Comandos disponibles:**
          - **-ayuda**: Muestra este mensaje de ayuda.
          - **-perfil**: Muestra tu perfil o el de otro usuario.
          - **-avatar [usuario]**: Muestra el avatar de un usuario. Si no se especifica, muestra el tuyo.
        `,
      )
      .setColor(0x4b0082)
      .setFooter({ text: "¡Gracias por usar el bot!" });

    await interaction.reply({ embeds: [ayudaEmbed], ephemeral: true });
  }

  // Respuesta para el botón de ayuda economía
  if (interaction.customId === "ayudaeconomia") {
    const economiaEmbed = new EmbedBuilder()
      .setTitle("Comandos de Economía")
      .setDescription(
        `
          **Comandos de Economía:**
          - **-trabajar**: Te permite trabajar y ganar dinero.
          - **-banco**: Muestra tu saldo bancario.
          - **-ruleta**: Juega a la ruleta con tu saldo.
          - **-blackjack**: Juega al blackjack con tu dinero.
          - **-robarbanco**: Intenta robar el banco para ganar dinero.
          - **-robarpersona**: Intenta robar a una persona para ganar dinero.
          - **-robarnegocio**: Intenta robar un negocio para ganar dinero.
          - **-dealer**: Vende drogas para ganar dinero.

          **Trabajos Especiales:**
          - **Juez**: Mantén el orden en el servidor.
          - **Policía**: Persigue criminales y mantén la paz.
        `,
      )
      .setColor(0x32a852)
      .setFooter({ text: "¡Gracias por usar el bot!" });

    await interaction.reply({ embeds: [economiaEmbed], ephemeral: true });
  }

  // Respuesta para el botón de ayuda moderación
  if (interaction.customId === "ayudamoderacion") {
    const moderacionEmbed = new EmbedBuilder()
      .setTitle("Comandos de Moderación")
      .setDescription(
        `
          **Comandos de Moderación:**
          - **-warn [usuario] [razón]**: Advierte a un usuario.
          - **-ban [usuario] [razón]**: Banea a un usuario.
          - **-unban [usuario]**: Desbanea a un usuario.
          - **-clearwarn [usuario]**: Elimina las advertencias de un usuario.
          - **-clear [cantidad]**: Elimina un número específico de mensajes.
          - **-tempmute [usuario] [tiempo en segundos] [razón]**: Silencia temporalmente a un usuario.
        `,
      )
      .setColor(0xff9900)
      .setFooter({ text: "¡Gracias por usar el bot!" });

    await interaction.reply({ embeds: [moderacionEmbed], ephemeral: true });
  }

  // Respuesta para el botón de ayuda entretenimiento
  if (interaction.customId === "ayudaentretenimiento") {
    const entretenimientoEmbed = new EmbedBuilder()
      .setTitle("Comandos de Entretenimiento")
      .setDescription(
        `
          **Comandos de Entretenimiento:**
          - **-adivinanza**: Resuelve una adivinanza divertida.
          - **-trivia**: Participa en una trivia.
          - **-meme**: Genera un meme al azar.
          - **-chiste**: Escucha un chiste aleatorio.
          - **-marry**: Casate con tu persona favorita :).
        `,
      )
      .setColor(0x0099ff)
      .setFooter({ text: "¡Gracias por usar el bot!" });

    await interaction.reply({ embeds: [entretenimientoEmbed], ephemeral: true });
  }
});

// Error Handlers
process.on("unhandledRejection", (error) => {
  console.error("Unhandled promise rejection:", error);
});

process.on("uncaughtException", (error) => {
  console.error("Uncaught exception:", error);
  process.exit(1); // Esto reinicia el bot si ocurre un error grave.
});

client.login(config.token);